import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        vault: {
          950: "#090d16",
          900: "#0f172a",
          800: "#1e293b",
          700: "#334155",
          accent: "#10b981",
          accentHover: "#059669"
        }
      }
    },
  },
  plugins: [],
};
export default config;
