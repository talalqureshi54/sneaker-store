-- KicksVault Production Database Schema
-- Run this in Supabase SQL Editor

-- 1. Enable UUID Extension
create extension if not exists "uuid-ossp";

-- 2. Products Table
create table if not exists public.products (
    id uuid default uuid_generate_v4() primary key,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    title text not null,
    slug text unique not null,
    description text,
    price integer not null,
    compare_at_price integer,
    cost_price integer,
    images text[] not null default '{}',
    sizes jsonb not null default '[{"size":"40","stock":5},{"size":"41","stock":8},{"size":"42","stock":10},{"size":"43","stock":6},{"size":"44","stock":4}]'::jsonb,
    is_featured boolean default true,
    status text default 'active' check (status in ('active', 'draft', 'archived')),
    tags text[] default array['streetwear', 'sneakers']
);

-- 3. Orders Table
create table if not exists public.orders (
    id uuid default uuid_generate_v4() primary key,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    order_number serial unique,
    customer_name text not null,
    phone text not null,
    city text not null,
    address text not null,
    product_id uuid references public.products(id),
    product_title text not null,
    selected_size text not null,
    quantity integer default 1,
    unit_price integer not null,
    total_amount integer not null,
    payment_method text default 'Cash on Delivery',
    order_status text default 'pending' check (order_status in ('pending', 'confirmed', 'dispatched', 'delivered', 'returned', 'cancelled')),
    courier_name text,
    courier_tracking_id text,
    notes text
);

-- 4. Enable RLS & Policies
alter table public.products enable row level security;
alter table public.orders enable row level security;

-- Public can read active products
create policy "Allow public read active products"
on public.products for select
using (status = 'active');

-- Public can insert new orders
create policy "Allow public insert orders"
on public.orders for insert
with check (true);

-- Storage bucket setup
insert into storage.buckets (id, name, public) 
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

create policy "Public Access Product Images"
on storage.objects for select
using ( bucket_id = 'product-images' );

create policy "Allow upload to product images"
on storage.objects for insert
with check ( bucket_id = 'product-images' );
