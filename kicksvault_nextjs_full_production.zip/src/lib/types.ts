export interface SizeStock {
  size: string;
  stock: number;
}

export interface Product {
  id: string;
  created_at: string;
  title: string;
  slug: string;
  description: string;
  price: number;
  compare_at_price: number;
  cost_price?: number;
  images: string[];
  sizes: SizeStock[];
  is_featured: boolean;
  status: 'active' | 'draft' | 'archived';
  tags: string[];
}

export interface OrderPayload {
  customerName: string;
  phone: string;
  city: string;
  address: string;
  productId: string;
  productTitle: string;
  selectedSize: string;
  unitPrice: number;
  totalAmount: number;
}
