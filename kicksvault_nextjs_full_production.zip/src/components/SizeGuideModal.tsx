export default function SizeGuideModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 max-w-md w-full rounded-2xl p-6 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white">
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <i className="fa-solid fa-ruler-combined text-emerald-400"></i> Shoe Size Chart & Guide
        </h3>
        <p className="text-xs text-slate-400 mt-1">Apne paon ka size deewar ke sath scale rakh kar centimeter (CM) mein napain:</p>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800 text-slate-200 uppercase font-bold">
              <tr>
                <th className="p-2.5">EU Size</th>
                <th className="p-2.5">US Men</th>
                <th className="p-2.5">Foot Length (CM)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              <tr><td className="p-2.5 font-bold text-white">40</td><td className="p-2.5">7.0</td><td className="p-2.5 text-emerald-400 font-semibold">25.0 cm</td></tr>
              <tr><td className="p-2.5 font-bold text-white">41</td><td className="p-2.5">8.0</td><td className="p-2.5 text-emerald-400 font-semibold">26.0 cm</td></tr>
              <tr><td className="p-2.5 font-bold text-white">42</td><td className="p-2.5">8.5 / 9.0</td><td className="p-2.5 text-emerald-400 font-semibold">26.5 cm</td></tr>
              <tr><td className="p-2.5 font-bold text-white">43</td><td className="p-2.5">9.5 / 10</td><td className="p-2.5 text-emerald-400 font-semibold">27.5 cm</td></tr>
              <tr><td className="p-2.5 font-bold text-white">44</td><td className="p-2.5">10.5</td><td className="p-2.5 text-emerald-400 font-semibold">28.0 cm</td></tr>
            </tbody>
          </table>
        </div>

        <div className="mt-4 p-3 bg-slate-800/60 rounded-lg text-[11px] text-slate-400 leading-relaxed border border-slate-700">
          💡 <span className="text-slate-200 font-semibold">Pro Tip:</span> Agar aap ka paon chaura (wide) hai, toh 1 size bara (e.g. 41 ke bajaye 42) order karein.
        </div>

        <button onClick={onClose} className="w-full mt-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2.5 rounded-lg text-xs transition">
          Samajh Aa Gaya
        </button>
      </div>
    </div>
  );
}
