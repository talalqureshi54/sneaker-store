export default function TrustBar() {
  return (
    <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-emerald-950/40 border-y border-emerald-500/20 py-3">
      <div className="max-w-6xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-center md:text-left">
        <div className="flex items-center justify-center md:justify-start gap-2.5">
          <i className="fa-solid fa-box-open text-emerald-400 text-lg"></i>
          <div>
            <div className="text-xs font-bold text-white">Open Parcel Delivery</div>
            <div className="text-[11px] text-slate-400">Pehle check, phir payment</div>
          </div>
        </div>
        <div className="flex items-center justify-center md:justify-start gap-2.5">
          <i className="fa-solid fa-arrows-rotate text-emerald-400 text-lg"></i>
          <div>
            <div className="text-xs font-bold text-white">3-Day Size Replacement</div>
            <div className="text-[11px] text-slate-400">Hassle-free size change</div>
          </div>
        </div>
        <div className="flex items-center justify-center md:justify-start gap-2.5">
          <i className="fa-solid fa-truck-fast text-emerald-400 text-lg"></i>
          <div>
            <div className="text-xs font-bold text-white">Free Nationwide COD</div>
            <div className="text-[11px] text-slate-400">No hidden delivery fees</div>
          </div>
        </div>
        <div className="flex items-center justify-center md:justify-start gap-2.5">
          <i className="fa-brands fa-whatsapp text-emerald-400 text-lg"></i>
          <div>
            <div className="text-xs font-bold text-white">Direct WhatsApp Support</div>
            <div className="text-[11px] text-slate-400">Instant size consultation</div>
          </div>
        </div>
      </div>
    </div>
  );
}
