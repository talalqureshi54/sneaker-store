'use client';

import Link from 'next/link';
import { Product } from '@/lib/types';

export default function ProductCard({ product }: { product: Product }) {
  const discountPercent = Math.round(
    ((product.compare_at_price - product.price) / product.compare_at_price) * 100
  );

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden hover:border-slate-700 transition flex flex-col justify-between group shadow-lg">
      <div>
        <Link href={`/product/${product.slug}`} className="block relative aspect-square overflow-hidden bg-slate-800">
          <img
            src={product.images[0] || 'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=600'}
            alt={product.title}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-500 ease-out"
            loading="lazy"
          />
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            <span className="bg-emerald-500 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider">
              IN STOCK
            </span>
            {discountPercent > 0 && (
              <span className="bg-red-500 text-white text-[10px] font-extrabold px-1.5 py-0.5 rounded uppercase">
                {discountPercent}% OFF
              </span>
            )}
          </div>
        </Link>

        <div className="p-4">
          <Link href={`/product/${product.slug}`}>
            <h3 className="font-bold text-sm text-white group-hover:text-emerald-400 transition line-clamp-1">
              {product.title}
            </h3>
          </Link>

          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-lg font-black text-emerald-400">Rs. {product.price.toLocaleString()}</span>
            {product.compare_at_price > product.price && (
              <span className="text-xs text-slate-500 line-through">Rs. {product.compare_at_price.toLocaleString()}</span>
            )}
          </div>

          <div className="mt-3 flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] text-slate-500 mr-1">Sizes:</span>
            {product.sizes.map((s) => (
              <span
                key={s.size}
                className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-semibold border ${
                  s.stock > 0
                    ? 'bg-slate-800 border-slate-700 text-slate-300'
                    : 'bg-slate-900/50 border-slate-800 text-slate-600 line-through'
                }`}
              >
                {s.size}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 pt-0">
        <Link
          href={`/product/${product.slug}`}
          className="w-full bg-slate-800 hover:bg-emerald-500 hover:text-slate-950 text-slate-200 font-bold py-2.5 rounded-xl text-xs transition flex items-center justify-center gap-2 group-hover:shadow-lg group-hover:shadow-emerald-500/10"
        >
          <i className="fa-solid fa-truck-fast"></i> Order Now (COD)
        </Link>
      </div>
    </div>
  );
}
