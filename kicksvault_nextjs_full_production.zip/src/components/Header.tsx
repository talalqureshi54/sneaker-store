import Link from 'next/link';

export default function Header() {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 text-slate-950 font-black flex items-center justify-center text-base tracking-tighter group-hover:scale-105 transition">
            KV
          </div>
          <span className="font-extrabold text-lg tracking-tight text-white">
            KICKS<span className="text-emerald-400">VAULT</span>
          </span>
        </Link>

        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-full text-xs text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Open Parcel COD Available</span>
          </div>
          <Link
            href="/admin"
            className="text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 transition flex items-center gap-1.5"
          >
            <i className="fa-solid fa-bolt text-amber-400"></i> Admin
          </Link>
        </div>
      </div>
    </header>
  );
}
