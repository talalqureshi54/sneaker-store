'use client';

import { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

export default function AdminPage() {
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [comparePrice, setComparePrice] = useState('');
  const [description, setDescription] = useState('');
  const [sizes, setSizes] = useState('40:4, 41:8, 42:10, 43:6, 44:4');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [alertMsg, setAlertMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      alert('Shoe photo select karein!');
      return;
    }

    setLoading(true);
    setAlertMsg(null);

    try {
      // 1. Upload Image to Supabase Bucket
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('product-images')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // 2. Get Public URL
      const { data: urlData } = supabase.storage
        .from('product-images')
        .getPublicUrl(fileName);

      const imageUrl = urlData.publicUrl;

      // 3. Parse Sizes Format (e.g. 40:4, 41:8)
      const parsedSizes = sizes.split(',').map((item) => {
        const [size, stock] = item.split(':').map((s) => s.trim());
        return { size, stock: parseInt(stock || '5', 10) };
      });

      // 4. Generate Slug
      const slug = title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)+/g, '') + `-${Date.now().toString().slice(-4)}`;

      // 5. Insert Product
      const { error: insertError } = await supabase.from('products').insert([
        {
          title,
          slug,
          description: description || 'Premium imported quality streetwear sneaker with durable sole.',
          price: parseInt(price, 10),
          compare_at_price: parseInt(comparePrice || price, 10),
          images: [imageUrl],
          sizes: parsedSizes,
          status: 'active',
          is_featured: true
        }
      ]);

      if (insertError) throw insertError;

      setAlertMsg({ type: 'success', text: 'Mubarak! Joota 1-click mein live website par chala gaya!' });
      setTitle('');
      setPrice('');
      setComparePrice('');
      setDescription('');
      setFile(null);

    } catch (err: any) {
      setAlertMsg({ type: 'error', text: 'Error: ' + err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4">
      <div className="max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
        <div className="flex items-center justify-between pb-5 border-b border-slate-800">
          <div>
            <h1 className="text-lg font-black text-white flex items-center gap-2">
              <i className="fa-solid fa-bolt text-amber-400"></i> 1-Click Sneaker Publisher
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">Mobile se photo select karein aur foran live store par chhorain</p>
          </div>
          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-bold px-2.5 py-1 rounded-full border border-emerald-500/20">
            PRO ADMIN
          </span>
        </div>

        {alertMsg && (
          <div
            className={`mt-4 p-3 rounded-xl text-xs font-semibold ${
              alertMsg.type === 'success'
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                : 'bg-red-500/10 text-red-400 border border-red-500/20'
            }`}
          >
            {alertMsg.text}
          </div>
        )}

        <form onSubmit={handlePublish} className="mt-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Shoe Photo (Wholesaler / Mobile Picture)</label>
            <input
              type="file"
              accept="image/*"
              required
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-300 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-emerald-500 file:text-slate-950 hover:file:bg-emerald-400"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Product Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Chunky Retro Skate - Off White"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Selling Price (Rs.)</label>
              <input
                type="number"
                required
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="3850"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Cut-Price / Compare (Rs.)</label>
              <input
                type="number"
                value={comparePrice}
                onChange={(e) => setComparePrice(e.target.value)}
                placeholder="5500"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Sizes & Initial Stock (Format: size:stock)</label>
            <input
              type="text"
              required
              value={sizes}
              onChange={(e) => setSizes(e.target.value)}
              placeholder="40:4, 41:8, 42:10, 43:6, 44:4"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Short Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="High quality sole, comfortable insole cushioning..."
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black py-3.5 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/20"
          >
            {loading ? (
              <span><i className="fa-solid fa-spinner fa-spin"></i> Uploading & Publishing...</span>
            ) : (
              <span><i className="fa-solid fa-cloud-arrow-up"></i> 1-Click Publish to Live Store</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
