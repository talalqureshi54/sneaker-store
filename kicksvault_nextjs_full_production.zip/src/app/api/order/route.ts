import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabaseClient';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { customerName, phone, city, address, productId, productTitle, selectedSize, unitPrice, totalAmount } = body;

    if (!customerName || !phone || !city || !address) {
      return NextResponse.json({ error: 'Tamam fields bharna zaroori hain' }, { status: 400 });
    }

    // Insert order into Supabase
    const { data: order, error } = await supabase
      .from('orders')
      .insert([
        {
          customer_name: customerName,
          phone,
          city,
          address,
          product_id: productId || null,
          product_title: productTitle,
          selected_size: selectedSize,
          unit_price: unitPrice,
          total_amount: totalAmount,
          order_status: 'pending',
          payment_method: 'Cash on Delivery'
        }
      ])
      .select('id, order_number')
      .single();

    if (error) {
      console.error('Supabase error:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      orderId: order.id,
      orderNumber: order.order_number
    });

  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
