import Header from '@/components/Header';
import TrustBar from '@/components/TrustBar';
import ProductCard from '@/components/ProductCard';
import { supabase } from '@/lib/supabaseClient';
import { Product } from '@/lib/types';

// Fallback dummy products if DB not yet filled
const fallbackProducts: Product[] = [
  {
    id: '1',
    created_at: new Date().toISOString(),
    title: 'Retro Chunky Skate Silhouette (Off-White/Grey)',
    slug: 'retro-chunky-skate-off-white',
    description: 'High-density rubber gum-sole with premium breathable synthetic mesh upper. Master craftsmanship designed for daily streetwear aesthetics.',
    price: 3850,
    compare_at_price: 5500,
    images: ['https://images.unsplash.com/photo-1552346154-21d32810aba3?w=800'],
    sizes: [
      { size: '40', stock: 4 },
      { size: '41', stock: 8 },
      { size: '42', stock: 12 },
      { size: '43', stock: 6 },
      { size: '44', stock: 3 }
    ],
    is_featured: true,
    status: 'active',
    tags: ['retro', 'streetwear']
  },
  {
    id: '2',
    created_at: new Date().toISOString(),
    title: 'Street Runner Vintage Trainer (Panda Edition)',
    slug: 'street-runner-vintage-panda',
    description: 'Classic monochrome dual-tone look. Lightweight impact cushion midsole with grip tread outer sole.',
    price: 4200,
    compare_at_price: 6000,
    images: ['https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800'],
    sizes: [
      { size: '41', stock: 5 },
      { size: '42', stock: 7 },
      { size: '43', stock: 4 }
    ],
    is_featured: true,
    status: 'active',
    tags: ['runner', 'panda']
  }
];

export const revalidate = 60; // ISR cache revalidation (lightning fast)

export default async function HomePage() {
  let products: Product[] = [];

  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (!error && data && data.length > 0) {
      products = data as Product[];
    } else {
      products = fallbackProducts;
    }
  } catch {
    products = fallbackProducts;
  }

  return (
    <>
      <Header />
      <TrustBar />

      <main className="max-w-6xl mx-auto px-4 py-8 flex-1 w-full">
        {/* Banner */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 mb-10 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <span className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
            Pakistan Direct-to-Consumer Drop
          </span>
          <h1 className="text-2xl sm:text-4xl font-black text-white mt-3 tracking-tight">
            Streetwear Footwear. <span className="text-emerald-400">Zero Compromise.</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto mt-2">
            Imported high-grade sneakers with <strong className="text-slate-200">Open Parcel Cash on Delivery</strong>. Pehle parcel khol kar check karein, phir rider ko cash dein.
          </p>
        </div>

        {/* Section Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-extrabold text-white">Trending Sneaker Drops</h2>
            <p className="text-xs text-slate-400">Selected high-demand silhouettes ready for immediate dispatch</p>
          </div>
          <span className="text-xs text-slate-400 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg">
            {products.length} Articles Live
          </span>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </main>

      <footer className="border-t border-slate-800 bg-slate-950 py-8 text-center text-xs text-slate-500">
        <div className="max-w-6xl mx-auto px-4">
          <p className="font-semibold text-slate-400">KicksVault Footwear Pakistan</p>
          <p className="mt-1">Rawalpindi / Islamabad / Mandra Regional Hub & Nationwide Courier Logistics</p>
          <p className="mt-4 text-[10px] text-slate-600">Built for ultra-fast performance with Next.js 15 & Supabase</p>
        </div>
      </footer>
    </>
  );
}
