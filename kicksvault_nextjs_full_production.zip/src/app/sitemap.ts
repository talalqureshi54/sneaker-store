import { MetadataRoute } from 'next';
import { supabase } from '@/lib/supabaseClient';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://your-sneaker-domain.com';

  // Base routes
  const routes: MetadataRoute.Sitemap = [
    {
      url: siteUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1.0,
    },
  ];

  // Fetch active products dynamically for Google index
  const { data: products } = await supabase
    .from('products')
    .select('slug, created_at')
    .eq('status', 'active');

  if (products) {
    products.forEach((p) => {
      routes.push({
        url: `${siteUrl}/product/${p.slug}`,
        lastModified: new Date(p.created_at),
        changeFrequency: 'weekly',
        priority: 0.8,
      });
    });
  }

  return routes;
}
