'use client';

import { useState } from 'react';
import { Product } from '@/lib/types';
import SizeGuideModal from '@/components/SizeGuideModal';

export default function ProductClientView({ product }: { product: Product }) {
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0]?.size || '41');
  const [activeImage, setActiveImage] = useState<string>(product.images[0]);
  const [showSizeGuide, setShowSizeGuide] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [orderComplete, setOrderComplete] = useState<boolean>(false);

  // Form State
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');

  const adminWhatsApp = process.env.NEXT_PUBLIC_ADMIN_WHATSAPP || '923001234567';

  const handleCodSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: name,
          phone,
          city,
          address,
          productId: product.id,
          productTitle: product.title,
          selectedSize,
          unitPrice: product.price,
          totalAmount: product.price
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to place order');

      setOrderComplete(true);

      // Trigger automatic WhatsApp redirect for customer verification
      const waMsg = 
        `*NEW COD ORDER #${data.orderNumber || ''}*%0A%0A` +
        `*Article:* ${product.title}%0A` +
        `*Size:* ${selectedSize}%0A` +
        `*Amount:* Rs. ${product.price.toLocaleString()} (Free Delivery)%0A%0A` +
        `*Customer Details:*%0A` +
        `Name: ${name}%0A` +
        `Phone: ${phone}%0A` +
        `City: ${city}%0A` +
        `Address: ${address}%0A%0A` +
        `_Note: Open Parcel Inspection Requested._`;

      setTimeout(() => {
        window.open(`https://wa.me/${adminWhatsApp}?text=${waMsg}`, '_blank');
      }, 1200);

    } catch (err: any) {
      alert('Order error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDirectWhatsApp = () => {
    const waMsg = 
      `Salam! Mujhe yeh sneaker order karna hai:%0A%0A` +
      `*Product:* ${product.title}%0A` +
      `*Size:* ${selectedSize}%0A` +
      `*Price:* Rs. ${product.price.toLocaleString()} (Free Delivery)%0A%0A` +
      `Mera delivery address note kar lein:`;
    window.open(`https://wa.me/${adminWhatsApp}?text=${waMsg}`, '_blank');
  };

  if (orderComplete) {
    return (
      <div className="max-w-md mx-auto bg-slate-900 border border-emerald-500/30 rounded-3xl p-8 text-center my-12 shadow-2xl">
        <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto text-2xl mb-4">
          <i className="fa-solid fa-check"></i>
        </div>
        <h2 className="text-xl font-bold text-white">Shukriya! Order Receive Ho Gaya</h2>
        <p className="text-xs text-slate-300 mt-2 leading-relaxed">
          Aap ka Cash on Delivery order note ho gaya hai. Hum aap ko WhatsApp par parcel tracking dispatch se pehle send karein ge.
        </p>
        <div className="mt-6 p-4 bg-slate-800/80 rounded-xl text-left text-xs space-y-1 text-slate-300">
          <div><strong className="text-white">Article:</strong> {product.title}</div>
          <div><strong className="text-white">Size:</strong> {selectedSize}</div>
          <div><strong className="text-white">Total Amount:</strong> Rs. {product.price.toLocaleString()} (Free Delivery)</div>
          <div><strong className="text-white">Delivery Terms:</strong> Open Parcel Inspection Allowed</div>
        </div>
        <a
          href="/"
          className="mt-6 inline-block bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-6 py-3 rounded-xl transition"
        >
          Mazeed Shoes Dekhein
        </a>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      <SizeGuideModal isOpen={showSizeGuide} onClose={() => setShowSizeGuide(false)} />

      {/* Product Image Gallery (Left 6 Cols) */}
      <div className="lg:col-span-6 space-y-3">
        <div className="aspect-square bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden relative">
          <img src={activeImage} alt={product.title} className="w-full h-full object-cover" />
          <span className="absolute top-3 left-3 bg-emerald-500 text-slate-950 font-black text-xs px-2.5 py-1 rounded">
            READY TO DISPATCH
          </span>
        </div>

        {product.images.length > 1 && (
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {product.images.map((img, i) => (
              <button
                key={i}
                onClick={() => setActiveImage(img)}
                className={`w-16 h-16 rounded-xl overflow-hidden border-2 flex-shrink-0 ${
                  activeImage === img ? 'border-emerald-500' : 'border-slate-800 opacity-60'
                }`}
              >
                <img src={img} className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        )}

        {/* Inspection Guarantee */}
        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl text-xs text-slate-300 flex items-start gap-3">
          <i className="fa-solid fa-shield-halved text-emerald-400 text-lg mt-0.5"></i>
          <div>
            <div className="font-bold text-white">100% Khareedar Ki Tasalli Guarantee</div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Rider ke samnay parcel khol kar joota check karein. Agar quality ya picture se farq niklay, toh bina kisi charge ke parcel rider ko wapis de dein.
            </div>
          </div>
        </div>
      </div>

      {/* Checkout & Detail Form (Right 6 Cols) */}
      <div className="lg:col-span-6 space-y-5 bg-slate-900 border border-slate-800 rounded-3xl p-6">
        <div>
          <span className="text-[11px] bg-slate-800 text-slate-400 px-2.5 py-1 rounded border border-slate-700 uppercase tracking-wider font-bold">
            Streetwear Edition
          </span>
          <h1 className="text-xl font-black text-white mt-2 leading-snug">{product.title}</h1>

          <div className="flex items-baseline gap-3 mt-2">
            <span className="text-2xl font-black text-emerald-400">Rs. {product.price.toLocaleString()}</span>
            {product.compare_at_price > product.price && (
              <span className="text-sm text-slate-500 line-through">Rs. {product.compare_at_price.toLocaleString()}</span>
            )}
            <span className="text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-semibold">
              Free Delivery Included
            </span>
          </div>
        </div>

        {/* Size Selector */}
        <div>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-bold text-slate-300">Select EU Size:</span>
            <button
              type="button"
              onClick={() => setShowSizeGuide(true)}
              className="text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
            >
              <i className="fa-solid fa-ruler-horizontal"></i> Size Chart (CM)
            </button>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {product.sizes.map((s) => {
              const isAvailable = s.stock > 0;
              const isSelected = selectedSize === s.size;
              return (
                <button
                  key={s.size}
                  type="button"
                  disabled={!isAvailable}
                  onClick={() => setSelectedSize(s.size)}
                  className={`py-2 text-xs font-mono font-bold rounded-xl border transition ${
                    isSelected
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-lg shadow-emerald-500/20'
                      : isAvailable
                      ? 'bg-slate-800 text-slate-200 border-slate-700 hover:border-slate-500'
                      : 'bg-slate-900 text-slate-600 border-slate-800 opacity-40 cursor-not-allowed line-through'
                  }`}
                >
                  {s.size}
                </button>
              );
            })}
          </div>
        </div>

        {/* Fast 1-Page COD Order Form */}
        <form onSubmit={handleCodSubmit} className="space-y-3 pt-2 border-t border-slate-800">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <i className="fa-solid fa-truck text-emerald-400"></i> Cash on Delivery Details
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-300 mb-1">Poora Naam (Full Name)</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Talal Abbas"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1">WhatsApp / Phone Number</label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="03001234567"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1">Sheher (City)</label>
              <input
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="e.g. Rawalpindi / Mandra"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-300 mb-1">Mukammal Delivery Pata</label>
            <textarea
              required
              rows={2}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Makan/Dukan number, Street, Mohalla ya qareebi mashhoor adda/chowk..."
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black py-3.5 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/20 active:scale-[0.99]"
          >
            {loading ? (
              <span><i className="fa-solid fa-spinner fa-spin"></i> Placing Order...</span>
            ) : (
              <span><i className="fa-solid fa-bag-shopping"></i> Complete Order - Cash on Delivery</span>
            )}
          </button>
        </form>

        <div className="relative text-center my-2">
          <span className="bg-slate-900 px-3 text-[11px] text-slate-500 relative z-10 font-bold uppercase">Ya Phir</span>
          <div className="absolute inset-0 top-1/2 border-t border-slate-800"></div>
        </div>

        <button
          type="button"
          onClick={handleDirectWhatsApp}
          className="w-full bg-slate-800 hover:bg-[#25D366] hover:text-slate-950 text-slate-300 font-bold py-2.5 rounded-xl text-xs transition flex items-center justify-center gap-2 border border-slate-700"
        >
          <i className="fa-brands fa-whatsapp text-sm"></i> Direct WhatsApp Par Order Karein
        </button>

        {/* Product Description */}
        <div className="pt-4 border-t border-slate-800 text-xs text-slate-400 leading-relaxed">
          <strong className="text-slate-200 block mb-1">Product Details:</strong>
          {product.description}
        </div>
      </div>
    </div>
  );
}
