import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Header from '@/components/Header';
import TrustBar from '@/components/TrustBar';
import ProductClientView from './ProductClientView';
import SeoSchema from '@/components/SeoSchema';
import { supabase } from '@/lib/supabaseClient';
import { Product } from '@/lib/types';

interface Props {
  params: Promise<{ slug: string }>;
}

async function getProduct(slug: string): Promise<Product | null> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('slug', slug)
    .single();

  if (error || !data) return null;
  return data as Product;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProduct(slug);

  if (!product) {
    return { title: 'Product Not Found' };
  }

  return {
    title: `${product.title} - Cash on Delivery`,
    description: product.description.slice(0, 150),
    openGraph: {
      title: `${product.title} | Rs. ${product.price}`,
      description: product.description.slice(0, 150),
      images: [{ url: product.images[0] }]
    }
  };
}

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  let product = await getProduct(slug);

  // Fallback demo for local testing
  if (!product) {
    if (slug === 'retro-chunky-skate-off-white') {
      product = {
        id: '1',
        created_at: new Date().toISOString(),
        title: 'Retro Chunky Skate Silhouette (Off-White/Grey)',
        slug: 'retro-chunky-skate-off-white',
        description: 'High-density rubber gum-sole with premium breathable synthetic mesh upper. Master craftsmanship designed for daily streetwear aesthetics.',
        price: 3850,
        compare_at_price: 5500,
        images: ['https://images.unsplash.com/photo-1552346154-21d32810aba3?w=800'],
        sizes: [
          { size: '40', stock: 4 },
          { size: '41', stock: 8 },
          { size: '42', stock: 12 },
          { size: '43', stock: 6 },
          { size: '44', stock: 3 }
        ],
        is_featured: true,
        status: 'active',
        tags: ['retro', 'streetwear']
      };
    } else {
      notFound();
    }
  }

  return (
    <>
      <Header />
      <TrustBar />
      <SeoSchema product={product} />
      <main className="max-w-5xl mx-auto px-4 py-8 flex-1">
        <ProductClientView product={product} />
      </main>
    </>
  );
}
