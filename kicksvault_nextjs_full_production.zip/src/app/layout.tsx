import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'),
  title: {
    default: "KicksVault Pakistan | Trending Streetwear & Skate Sneakers",
    template: "%s | KicksVault"
  },
  description: "Shop imported streetwear retro sneakers, chunky skate shoes & runners with Open Parcel Cash on Delivery across Pakistan.",
  openGraph: {
    title: "KicksVault Pakistan - Trending Sneakers",
    description: "Premium Sneakers with Open Parcel Cash on Delivery across Pakistan.",
    type: "website",
    locale: "en_PK",
    siteName: "KicksVault"
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
      </head>
      <body className="bg-slate-950 text-slate-100 antialiased selection:bg-emerald-500 selection:text-slate-950 font-sans min-h-screen flex flex-col">
        {children}
      </body>
    </html>
  );
}
